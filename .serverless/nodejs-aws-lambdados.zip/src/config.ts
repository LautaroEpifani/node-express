export const keys = {
    secret: 'mysecret'
}